import React from 'react';
import { motion } from 'framer-motion';

const Hero = () => {
  return (
    <section id="home" className="relative min-h-screen flex items-center justify-center overflow-hidden">
      {/* Background Image */}
      <div className="absolute inset-0 z-0">
        <img
          src="/assets_task_01jyy6h8s2esh866ynkeatrbsx_1751212699_img_0.webp"
          alt="Tattoo artist working in studio"
          className="w-full h-full object-cover"
        />
        <div className="absolute inset-0 bg-gradient-to-b from-black/60 via-black/70 to-black/80"></div>
      </div>

      {/* Content */}
      <div className="relative z-10 text-center px-4 max-w-5xl mx-auto">
        <motion.div
          initial={{ opacity: 0, scale: 0.8 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 1.2, delay: 0.2, ease: "easeOut" }}
          className="relative"
        >
          <motion.h1
            initial={{ opacity: 0, y: 100 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 1.4, delay: 0.4, ease: "easeOut" }}
            className="font-playfair text-5xl md:text-7xl lg:text-8xl xl:text-9xl font-bold text-white mb-8 relative"
          >
            <span className="relative inline-block">
              Linden
              <motion.div
                initial={{ scaleX: 0 }}
                animate={{ scaleX: 1 }}
                transition={{ duration: 1, delay: 1.2, ease: "easeInOut" }}
                className="absolute -bottom-2 left-0 right-0 h-1 bg-gradient-to-r from-transparent via-gold to-transparent origin-center"
              />
            </span>
            <br />
            <motion.span
              initial={{ opacity: 0, x: -50 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 1, delay: 0.8, ease: "easeOut" }}
              className="relative inline-block bg-gradient-to-r from-gold via-gold-light to-gold bg-clip-text text-transparent"
            >
              Art
              <motion.div
                initial={{ rotate: 0, scale: 0 }}
                animate={{ rotate: 360, scale: 1 }}
                transition={{ duration: 0.8, delay: 1.6, ease: "easeOut" }}
                className="absolute -top-4 -right-8 w-6 h-6 border-2 border-gold rounded-full"
              />
            </motion.span>
          </motion.h1>

          {/* Decorative elements */}
          <motion.div
            initial={{ opacity: 0, scale: 0 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.6, delay: 1.8 }}
            className="absolute -top-8 left-1/4 w-2 h-2 bg-gold rounded-full"
          />
          <motion.div
            initial={{ opacity: 0, scale: 0 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.6, delay: 2 }}
            className="absolute -top-12 right-1/3 w-1 h-1 bg-gold-light rounded-full"
          />
          <motion.div
            initial={{ opacity: 0, scale: 0 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.6, delay: 2.2 }}
            className="absolute -bottom-6 left-1/3 w-3 h-3 border border-gold rounded-full"
          />
        </motion.div>

        <motion.p
          initial={{ opacity: 0, y: 50 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 1, delay: 1.4, ease: "easeOut" }}
          className="font-inter text-xl md:text-2xl lg:text-3xl text-gold font-medium tracking-wider relative"
        >
          <motion.span
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 0.8, delay: 2.4 }}
            className="relative"
          >
            Carve your truth, wear it forever.
            <motion.div
              initial={{ width: 0 }}
              animate={{ width: "100%" }}
              transition={{ duration: 1.2, delay: 2.6, ease: "easeInOut" }}
              className="absolute -bottom-1 left-0 h-px bg-gradient-to-r from-transparent via-gold/50 to-transparent"
            />
          </motion.span>
        </motion.p>
      </div>

      {/* Ambient light effects */}
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 0.3 }}
        transition={{ duration: 2, delay: 1 }}
        className="absolute top-1/4 left-1/4 w-96 h-96 bg-gold/10 rounded-full blur-3xl"
      />
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 0.2 }}
        transition={{ duration: 2.5, delay: 1.5 }}
        className="absolute bottom-1/4 right-1/4 w-80 h-80 bg-gold-light/10 rounded-full blur-3xl"
      />
    </section>
  );
};

export default Hero;