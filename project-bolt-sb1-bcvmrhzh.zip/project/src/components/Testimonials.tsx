import React from 'react';
import { motion } from 'framer-motion';
import { Star, Sparkles, Heart, Award, Zap, Crown } from 'lucide-react';

const Testimonials = () => {
  const testimonials = [
    {
      name: "Sarah M.",
      text: "Linden transformed my vision into something even more beautiful than I imagined. The attention to detail and artistic skill is unmatched.",
      rating: 5
    },
    {
      name: "Michael R.",
      text: "Professional, clean, and incredibly talented. My sleeve took months to complete, but every session was worth it for the incredible result.",
      rating: 5
    },
    {
      name: "Emma K.",
      text: "From consultation to completion, the experience was flawless. Linden really listens and creates something uniquely yours.",
      rating: 5
    },
    {
      name: "David L.",
      text: "I've gotten work done by many artists, but Linden's artistry and professionalism stand out. Highly recommend for anyone serious about quality.",
      rating: 5
    }
  ];

  return (
    <section id="testimonials" className="py-20 bg-gray-900 relative overflow-hidden">
      {/* Enhanced background decorative elements with gold theme */}
      <div className="absolute inset-0 opacity-10">
        <motion.div 
          animate={{ rotate: 360, scale: [1, 1.2, 1] }}
          transition={{ duration: 20, repeat: Infinity, ease: "linear" }}
          className="absolute top-20 left-10 w-32 h-32 border-2 border-gold rounded-full"
        />
        <motion.div 
          animate={{ scale: [1, 1.5, 1], opacity: [0.1, 0.3, 0.1] }}
          transition={{ duration: 4, repeat: Infinity, ease: "easeInOut" }}
          className="absolute bottom-40 right-20 w-24 h-24 bg-gradient-to-r from-gold/20 to-gold-light/20 rounded-full blur-xl"
        />
        <motion.div 
          animate={{ y: [0, -20, 0], x: [0, 10, 0] }}
          transition={{ duration: 3, repeat: Infinity, ease: "easeInOut" }}
          className="absolute top-1/2 left-1/4 w-4 h-4 bg-gradient-to-r from-gold to-gold-light rounded-full shadow-lg shadow-gold/50"
        />
        <motion.div 
          animate={{ y: [0, 15, 0], x: [0, -8, 0] }}
          transition={{ duration: 2.5, repeat: Infinity, ease: "easeInOut", delay: 1 }}
          className="absolute top-1/3 right-1/3 w-3 h-3 bg-gradient-to-r from-gold-light to-gold rounded-full shadow-lg shadow-gold-light/50"
        />
        
        {/* Additional floating elements with gold theme */}
        <motion.div 
          animate={{ rotate: [0, 180, 360] }}
          transition={{ duration: 8, repeat: Infinity, ease: "linear" }}
          className="absolute top-1/4 right-1/4 text-gold"
        >
          <Zap size={24} />
        </motion.div>
        <motion.div 
          animate={{ scale: [1, 1.3, 1], rotate: [0, 15, 0] }}
          transition={{ duration: 3, repeat: Infinity, ease: "easeInOut", delay: 2 }}
          className="absolute bottom-1/3 left-1/3 text-gold-light"
        >
          <Crown size={20} />
        </motion.div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          viewport={{ once: true }}
          className="text-center mb-16 relative"
        >
          {/* Enhanced main heading with gold gradient and glow */}
          <motion.h2 
            initial={{ scale: 0.8 }}
            whileInView={{ scale: 1 }}
            transition={{ duration: 0.8, delay: 0.2 }}
            viewport={{ once: true }}
            className="font-playfair text-4xl md:text-5xl font-bold mb-4 relative"
          >
            <span className="bg-gradient-to-r from-gold via-gold-light to-gold bg-clip-text text-transparent drop-shadow-2xl">
              Client Stories
            </span>
            <motion.div
              animate={{ scale: [1, 1.1, 1], opacity: [0.5, 1, 0.5] }}
              transition={{ duration: 2, repeat: Infinity, ease: "easeInOut" }}
              className="absolute -inset-4 bg-gradient-to-r from-gold/20 via-gold-light/30 to-gold/20 rounded-lg blur-xl -z-10"
            />
          </motion.h2>
          
          <motion.p 
            initial={{ opacity: 0 }}
            whileInView={{ opacity: 1 }}
            transition={{ duration: 0.6, delay: 0.4 }}
            viewport={{ once: true }}
            className="font-inter text-lg text-gray-300 max-w-2xl mx-auto relative"
          >
            Don't just take our word for it. Here's what our clients have to say about their 
            <span className="bg-gradient-to-r from-gold to-gold-light bg-clip-text text-transparent font-semibold"> extraordinary </span>
            experience.
          </motion.p>

          {/* Decorative sparkles around heading */}
          <motion.div
            animate={{ rotate: 360, scale: [1, 1.2, 1] }}
            transition={{ duration: 4, repeat: Infinity, ease: "easeInOut" }}
            className="absolute -top-4 -left-8 text-gold"
          >
            <Sparkles size={20} />
          </motion.div>
          <motion.div
            animate={{ rotate: -360, scale: [1, 1.3, 1] }}
            transition={{ duration: 5, repeat: Infinity, ease: "easeInOut", delay: 1 }}
            className="absolute -top-2 -right-6 text-gold-light"
          >
            <Sparkles size={16} />
          </motion.div>
        </motion.div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          {testimonials.map((testimonial, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: index * 0.1 }}
              viewport={{ once: true }}
              className="bg-black border border-gray-800 p-8 rounded-lg hover:border-gold/30 transition-colors duration-300"
            >
              {/* Stars */}
              <div className="flex space-x-1 mb-4">
                {[...Array(testimonial.rating)].map((_, i) => (
                  <Star key={i} size={20} className="text-gold fill-current" />
                ))}
              </div>

              {/* Quote */}
              <blockquote className="font-inter text-gray-300 text-lg leading-relaxed mb-6">
                "{testimonial.text}"
              </blockquote>

              {/* Name */}
              <cite className="font-inter text-white font-semibold not-italic">
                — {testimonial.name}
              </cite>
            </motion.div>
          ))}
        </div>

        {/* Enhanced Call to Action Section with gold theme */}
        <motion.div
          initial={{ opacity: 0, y: 50 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.4 }}
          viewport={{ once: true }}
          className="mt-20 relative"
        >
          {/* Gradient background with gold glow effects */}
          <div className="absolute inset-0 bg-gradient-to-r from-gold/5 via-gold-light/10 to-gold/5 rounded-3xl blur-xl"></div>
          <div className="absolute inset-0 bg-gradient-to-b from-transparent via-gold/5 to-transparent rounded-3xl"></div>
          
          <div className="relative bg-gradient-to-br from-gray-900/90 via-black/95 to-gray-900/90 border border-gold/20 rounded-3xl p-12 backdrop-blur-sm">
            {/* Decorative corner elements */}
            <div className="absolute top-6 left-6 w-8 h-8 border-l-2 border-t-2 border-gold/40"></div>
            <div className="absolute top-6 right-6 w-8 h-8 border-r-2 border-t-2 border-gold/40"></div>
            <div className="absolute bottom-6 left-6 w-8 h-8 border-l-2 border-b-2 border-gold/40"></div>
            <div className="absolute bottom-6 right-6 w-8 h-8 border-r-2 border-b-2 border-gold/40"></div>

            {/* Floating decorative elements */}
            <motion.div
              animate={{ 
                y: [0, -10, 0],
                rotate: [0, 5, 0]
              }}
              transition={{ 
                duration: 4,
                repeat: Infinity,
                ease: "easeInOut"
              }}
              className="absolute top-8 left-1/4 text-gold/60"
            >
              <Sparkles size={24} />
            </motion.div>
            
            <motion.div
              animate={{ 
                y: [0, 10, 0],
                rotate: [0, -5, 0]
              }}
              transition={{ 
                duration: 3,
                repeat: Infinity,
                ease: "easeInOut",
                delay: 1
              }}
              className="absolute bottom-8 right-1/4 text-gold-light/60"
            >
              <Heart size={20} />
            </motion.div>

            <motion.div
              animate={{ 
                scale: [1, 1.1, 1],
                opacity: [0.3, 0.6, 0.3]
              }}
              transition={{ 
                duration: 2,
                repeat: Infinity,
                ease: "easeInOut",
                delay: 0.5
              }}
              className="absolute top-1/2 right-12 text-gold/40"
            >
              <Award size={28} />
            </motion.div>

            <div className="text-center relative z-10">
              <motion.div
                initial={{ scale: 0.8, opacity: 0 }}
                whileInView={{ scale: 1, opacity: 1 }}
                transition={{ duration: 0.6, delay: 0.2 }}
                viewport={{ once: true }}
                className="mb-8"
              >
                <h3 className="font-playfair text-3xl md:text-4xl font-bold text-white mb-4">
                  Ready to Start Your
                  <span className="block bg-gradient-to-r from-gold via-gold-light to-gold bg-clip-text text-transparent">
                    Tattoo Journey?
                  </span>
                </h3>
                <p className="font-inter text-lg text-gray-300 max-w-2xl mx-auto leading-relaxed">
                  Join hundreds of satisfied clients who've trusted their vision to our artistry. 
                  Let's create something extraordinary together.
                </p>
              </motion.div>

              {/* Stats section */}
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.6, delay: 0.4 }}
                viewport={{ once: true }}
                className="grid grid-cols-3 gap-8 mb-10"
              >
                <div className="text-center">
                  <div className="text-3xl md:text-4xl font-bold text-gold mb-2">500+</div>
                  <div className="text-sm text-gray-400 font-inter">Happy Clients</div>
                </div>
                <div className="text-center">
                  <div className="text-3xl md:text-4xl font-bold text-gold mb-2">10+</div>
                  <div className="text-sm text-gray-400 font-inter">Years Experience</div>
                </div>
                <div className="text-center">
                  <div className="text-3xl md:text-4xl font-bold text-gold mb-2">5★</div>
                  <div className="text-sm text-gray-400 font-inter">Average Rating</div>
                </div>
              </motion.div>

              {/* CTA Buttons */}
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.6, delay: 0.6 }}
                viewport={{ once: true }}
                className="flex flex-col sm:flex-row gap-4 justify-center items-center"
              >
                <motion.button
                  whileHover={{ 
                    scale: 1.05,
                    boxShadow: "0 20px 40px rgba(212, 175, 55, 0.3)"
                  }}
                  whileTap={{ scale: 0.95 }}
                  onClick={() => {
                    const element = document.getElementById('contact');
                    if (element) element.scrollIntoView({ behavior: 'smooth' });
                  }}
                  className="bg-gradient-to-r from-gold to-gold-light hover:from-gold-light hover:to-gold text-black font-inter font-bold px-10 py-4 rounded-full transition-all duration-300 transform shadow-lg shadow-gold/25 relative overflow-hidden group"
                >
                  <span className="relative z-10">Book Your Consultation</span>
                  <motion.div
                    className="absolute inset-0 bg-gradient-to-r from-gold-light to-gold opacity-0 group-hover:opacity-100 transition-opacity duration-300"
                  />
                </motion.button>

                <motion.button
                  whileHover={{ 
                    scale: 1.05,
                    borderColor: "rgba(212, 175, 55, 0.8)"
                  }}
                  whileTap={{ scale: 0.95 }}
                  onClick={() => {
                    const element = document.getElementById('portfolio');
                    if (element) element.scrollIntoView({ behavior: 'smooth' });
                  }}
                  className="border-2 border-gold/50 hover:border-gold text-gold hover:text-white hover:bg-gold/10 font-inter font-semibold px-10 py-4 rounded-full transition-all duration-300 backdrop-blur-sm"
                >
                  View More Work
                </motion.button>
              </motion.div>

              {/* Trust indicators */}
              <motion.div
                initial={{ opacity: 0 }}
                whileInView={{ opacity: 1 }}
                transition={{ duration: 0.6, delay: 0.8 }}
                viewport={{ once: true }}
                className="mt-8 flex justify-center items-center space-x-6 text-sm text-gray-400"
              >
                <div className="flex items-center space-x-2">
                  <div className="w-2 h-2 bg-green-400 rounded-full"></div>
                  <span>Licensed & Insured</span>
                </div>
                <div className="flex items-center space-x-2">
                  <div className="w-2 h-2 bg-blue-400 rounded-full"></div>
                  <span>Sterile Environment</span>
                </div>
                <div className="flex items-center space-x-2">
                  <div className="w-2 h-2 bg-gold rounded-full"></div>
                  <span>Custom Designs</span>
                </div>
              </motion.div>
            </div>
          </div>
        </motion.div>
      </div>
    </section>
  );
};

export default Testimonials;