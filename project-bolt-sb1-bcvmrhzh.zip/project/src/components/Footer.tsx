import React from 'react';
import { motion } from 'framer-motion';
import { Instagram, Facebook, Heart } from 'lucide-react';
import Logo from './Logo';

const Footer = () => {
  const currentYear = new Date().getFullYear();

  return (
    <footer className="bg-gray-900 border-t border-gray-800 py-12">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-8">
          {/* Brand */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            viewport={{ once: true }}
          >
            <div className="flex items-center space-x-3 mb-4">
              <Logo size={32} className="text-gold" />
              <h3 className="font-playfair text-2xl font-bold text-white">
                Linden Art
              </h3>
            </div>
            <p className="font-inter text-gray-400 leading-relaxed">
              Premium custom tattoo artistry where creativity meets craftsmanship. 
              Every piece tells a story.
            </p>
          </motion.div>

          {/* Quick Links */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.1 }}
            viewport={{ once: true }}
          >
            <h4 className="font-inter text-lg font-semibold text-white mb-4">
              Quick Links
            </h4>
            <ul className="space-y-2">
              {['Portfolio', 'About', 'Testimonials', 'Contact'].map((link) => (
                <li key={link}>
                  <button
                    onClick={() => {
                      const element = document.getElementById(link.toLowerCase());
                      if (element) element.scrollIntoView({ behavior: 'smooth' });
                    }}
                    className="font-inter text-gray-400 hover:text-gold transition-colors duration-200"
                  >
                    {link}
                  </button>
                </li>
              ))}
            </ul>
          </motion.div>

          {/* Social & Contact */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.2 }}
            viewport={{ once: true }}
          >
            <h4 className="font-inter text-lg font-semibold text-white mb-4">
              Connect
            </h4>
            <div className="flex space-x-4 mb-4">
              <motion.a
                href="https://www.facebook.com/linden.art.2025/"
                whileHover={{ scale: 1.1 }}
                whileTap={{ scale: 0.9 }}
                className="text-gray-400 hover:text-gold transition-colors duration-200"
              >
                <Facebook size={24} />
              </motion.a>
              <motion.a
                href="https://www.instagram.com/lindenart_ink/"
                whileHover={{ scale: 1.1 }}
                whileTap={{ scale: 0.9 }}
                className="text-gray-400 hover:text-gold transition-colors duration-200"
              >
                <Instagram size={24} />
              </motion.a>
            </div>
            <p className="font-inter text-gray-400 text-sm">
              1401/180-186 Burwood Rd<br />
              Burwood, NSW 2134
            </p>
          </motion.div>
        </div>

        <div className="border-t border-gray-800 pt-8">
          <div className="flex flex-col md:flex-row justify-between items-center">
            <p className="font-inter text-gray-400 text-sm mb-4 md:mb-0">
              © {currentYear} Linden Art. All rights reserved.
            </p>
            <motion.p
              initial={{ opacity: 0 }}
              whileInView={{ opacity: 1 }}
              transition={{ duration: 0.6 }}
              viewport={{ once: true }}
              className="font-inter text-gray-400 text-sm flex items-center"
            >
              Made with <Heart size={16} className="mx-1 text-gold" /> for the art of tattooing
            </motion.p>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;