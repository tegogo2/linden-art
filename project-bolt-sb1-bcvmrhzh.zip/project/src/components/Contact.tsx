import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Facebook, Instagram, MapPin, Send, Sparkles, Zap, CheckCircle, AlertCircle } from 'lucide-react';

const Contact = () => {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    message: ''
  });
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [submitStatus, setSubmitStatus] = useState<'idle' | 'success' | 'error'>('idle');
  const [errorMessage, setErrorMessage] = useState('');

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
    // Clear any previous error status when user starts typing
    if (submitStatus === 'error') {
      setSubmitStatus('idle');
      setErrorMessage('');
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);
    setSubmitStatus('idle');
    setErrorMessage('');
    
    try {
      const response = await fetch('https://hook.eu2.make.com/01nr9rorlyjs2wxq7xw2j7cskiup6vms', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          name: formData.name,
          email: formData.email,
          message: formData.message,
          timestamp: new Date().toISOString(),
          source: 'Linden Art Website'
        }),
      });

      if (response.ok) {
        setSubmitStatus('success');
        setFormData({ name: '', email: '', message: '' });
        
        // Reset success message after 5 seconds
        setTimeout(() => setSubmitStatus('idle'), 5000);
      } else {
        throw new Error(`Server responded with status: ${response.status}`);
      }
    } catch (error) {
      console.error('Form submission error:', error);
      setSubmitStatus('error');
      setErrorMessage('Failed to send message. Please try again or contact us directly.');
    } finally {
      setIsSubmitting(false);
    }
  };

  const contactInfo = [
    {
      icon: <Facebook size={24} />,
      label: "Facebook",
      value: "@linden.art.2025",
      href: "https://www.facebook.com/linden.art.2025/",
      isExternal: true
    },
    {
      icon: <Instagram size={24} />,
      label: "Instagram",
      value: "@lindenart_ink",
      href: "https://www.instagram.com/lindenart_ink/",
      isExternal: true
    },
    {
      icon: <MapPin size={24} />,
      label: "Studio",
      value: "1401/180-186 Burwood Rd, Burwood, NSW 2134",
      href: "https://maps.google.com/?q=1401/180-186+Burwood+Rd,+Burwood,+NSW+2134",
      isExternal: true
    }
  ];

  return (
    <section id="contact" className="py-20 bg-black relative overflow-hidden">
      {/* Enhanced background elements with gold theme */}
      <div className="absolute inset-0 opacity-10 pointer-events-none" aria-hidden="true">
        <motion.div 
          animate={{ rotate: 360, scale: [1, 1.3, 1] }}
          transition={{ duration: 18, repeat: Infinity, ease: "linear" }}
          className="absolute top-24 right-32 w-28 h-28 border-2 border-gold rounded-full"
        />
        <motion.div 
          animate={{ scale: [1, 1.6, 1], opacity: [0.1, 0.4, 0.1] }}
          transition={{ duration: 6, repeat: Infinity, ease: "easeInOut" }}
          className="absolute bottom-32 left-24 w-40 h-40 bg-gradient-to-r from-gold/20 to-gold-light/20 rounded-full blur-3xl"
        />
        <motion.div
          animate={{ y: [0, -25, 0], rotate: [0, 180, 360] }}
          transition={{ duration: 5, repeat: Infinity, ease: "easeInOut" }}
          className="absolute top-1/3 left-1/4 text-gold/60"
        >
          <Zap size={22} />
        </motion.div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          viewport={{ once: true }}
          className="text-center mb-16 relative"
        >
          {/* Enhanced "Book Now" heading with gold theme */}
          <motion.h2 
            initial={{ scale: 0.8, opacity: 0 }}
            whileInView={{ scale: 1, opacity: 1 }}
            transition={{ duration: 0.8, delay: 0.2 }}
            viewport={{ once: true }}
            className="font-playfair text-4xl md:text-5xl font-bold mb-4 relative"
          >
            <span className="bg-gradient-to-r from-gold via-gold-light to-gold bg-clip-text text-transparent drop-shadow-2xl">
              Book Now
            </span>
            <motion.div
              animate={{ scale: [1, 1.2, 1], opacity: [0.4, 0.9, 0.4] }}
              transition={{ duration: 3, repeat: Infinity, ease: "easeInOut" }}
              className="absolute -inset-6 bg-gradient-to-r from-gold/20 via-gold-light/30 to-gold/20 rounded-2xl blur-2xl -z-10 pointer-events-none"
            />
          </motion.h2>

          {/* Decorative sparkles around heading */}
          <motion.div
            animate={{ rotate: 360, scale: [1, 1.4, 1] }}
            transition={{ duration: 5, repeat: Infinity, ease: "easeInOut" }}
            className="absolute -top-6 -left-10 text-gold pointer-events-none"
            aria-hidden="true"
          >
            <Sparkles size={24} />
          </motion.div>
          <motion.div
            animate={{ rotate: -360, scale: [1, 1.3, 1] }}
            transition={{ duration: 6, repeat: Infinity, ease: "easeInOut", delay: 1.5 }}
            className="absolute -top-4 -right-8 text-gold-light pointer-events-none"
            aria-hidden="true"
          >
            <Sparkles size={20} />
          </motion.div>

          <motion.p 
            initial={{ opacity: 0 }}
            whileInView={{ opacity: 1 }}
            transition={{ duration: 0.6, delay: 0.4 }}
            viewport={{ once: true }}
            className="font-inter text-lg text-gray-400 max-w-2xl mx-auto"
          >
            Ready to bring your vision to life? Get in touch to discuss your 
            <span className="bg-gradient-to-r from-gold to-gold-light bg-clip-text text-transparent font-semibold"> next piece</span>.
          </motion.p>
        </motion.div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-16">
          {/* Contact Form */}
          <motion.div
            initial={{ opacity: 0, x: -50 }}
            whileInView={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.8 }}
            viewport={{ once: true }}
            className="relative z-20"
          >
            <form onSubmit={handleSubmit} className="space-y-6" noValidate>
              <div>
                <label 
                  htmlFor="name" 
                  className="block font-inter text-sm font-medium text-gray-300 mb-2"
                >
                  Name <span className="text-gold" aria-label="required">*</span>
                </label>
                <input
                  type="text"
                  id="name"
                  name="name"
                  value={formData.name}
                  onChange={handleInputChange}
                  required
                  aria-required="true"
                  className="w-full px-4 py-3 bg-gray-900 border border-gray-700 text-white font-inter focus:outline-none focus:border-gold focus:ring-2 focus:ring-gold/20 transition-all duration-200 relative z-30"
                  placeholder="Your full name"
                  style={{ pointerEvents: 'auto' }}
                />
              </div>

              <div>
                <label 
                  htmlFor="email" 
                  className="block font-inter text-sm font-medium text-gray-300 mb-2"
                >
                  Email <span className="text-gold" aria-label="required">*</span>
                </label>
                <input
                  type="email"
                  id="email"
                  name="email"
                  value={formData.email}
                  onChange={handleInputChange}
                  required
                  aria-required="true"
                  className="w-full px-4 py-3 bg-gray-900 border border-gray-700 text-white font-inter focus:outline-none focus:border-gold focus:ring-2 focus:ring-gold/20 transition-all duration-200 relative z-30"
                  placeholder="your.email@example.com"
                  style={{ pointerEvents: 'auto' }}
                />
              </div>

              <div>
                <label 
                  htmlFor="message" 
                  className="block font-inter text-sm font-medium text-gray-300 mb-2"
                >
                  Message <span className="text-gold" aria-label="required">*</span>
                </label>
                <textarea
                  id="message"
                  name="message"
                  value={formData.message}
                  onChange={handleInputChange}
                  required
                  aria-required="true"
                  rows={6}
                  className="w-full px-4 py-3 bg-gray-900 border border-gray-700 text-white font-inter focus:outline-none focus:border-gold focus:ring-2 focus:ring-gold/20 transition-all duration-200 resize-none relative z-30"
                  placeholder="Tell me about your tattoo idea, preferred style, size, placement, and any reference images you have..."
                  style={{ pointerEvents: 'auto' }}
                />
                <p className="mt-2 text-sm text-gray-500">
                  Include details about style, size, placement, and any reference images you have.
                </p>
              </div>

              <motion.button
                type="submit"
                disabled={isSubmitting || !formData.name.trim() || !formData.email.trim() || !formData.message.trim()}
                whileHover={{ scale: isSubmitting ? 1 : 1.02 }}
                whileTap={{ scale: isSubmitting ? 1 : 0.98 }}
                className="w-full bg-gold hover:bg-gold-light disabled:bg-gold/50 disabled:cursor-not-allowed text-black font-inter font-semibold px-8 py-4 transition-all duration-300 flex items-center justify-center space-x-2 focus:outline-none focus:ring-2 focus:ring-gold/50 focus:ring-offset-2 focus:ring-offset-black relative z-30"
                style={{ pointerEvents: 'auto' }}
              >
                {isSubmitting ? (
                  <>
                    <div 
                      className="animate-spin w-5 h-5 border-2 border-black border-t-transparent rounded-full" 
                      aria-hidden="true"
                    />
                    <span>Sending...</span>
                  </>
                ) : (
                  <>
                    <Send size={20} aria-hidden="true" />
                    <span>Send Message</span>
                  </>
                )}
              </motion.button>

              {/* Status Messages */}
              {submitStatus === 'success' && (
                <motion.div
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  role="status"
                  aria-live="polite"
                  className="flex items-center space-x-2 text-green-400 font-inter text-center py-2"
                >
                  <CheckCircle size={20} aria-hidden="true" />
                  <span>Message sent successfully! I'll get back to you soon.</span>
                </motion.div>
              )}

              {submitStatus === 'error' && (
                <motion.div
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  role="alert"
                  aria-live="assertive"
                  className="flex items-center space-x-2 text-red-400 font-inter text-center py-2"
                >
                  <AlertCircle size={20} aria-hidden="true" />
                  <span>{errorMessage}</span>
                </motion.div>
              )}
            </form>
          </motion.div>

          {/* Contact Information */}
          <motion.div
            initial={{ opacity: 0, x: 50 }}
            whileInView={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.8 }}
            viewport={{ once: true }}
            className="space-y-8 relative z-20"
          >
            <div>
              <motion.h3 
                initial={{ scale: 0.9, opacity: 0 }}
                whileInView={{ scale: 1, opacity: 1 }}
                transition={{ duration: 0.6, delay: 0.2 }}
                viewport={{ once: true }}
                className="font-playfair text-2xl font-bold mb-6 relative"
              >
                <span className="bg-gradient-to-r from-gold via-gold-light to-gold bg-clip-text text-transparent">
                  Get In Touch
                </span>
                <motion.div
                  animate={{ scale: [1, 1.1, 1], opacity: [0.3, 0.6, 0.3] }}
                  transition={{ duration: 2.5, repeat: Infinity, ease: "easeInOut" }}
                  className="absolute -inset-3 bg-gradient-to-r from-gold/15 via-gold-light/20 to-gold/15 rounded-lg blur-lg -z-10 pointer-events-none"
                  aria-hidden="true"
                />
              </motion.h3>
              <p className="font-inter text-gray-400 leading-relaxed mb-8">
                I'm always excited to discuss new projects and bring creative visions to life. 
                Whether you have a detailed concept or just an idea, let's talk about how we can 
                create something amazing together.
              </p>
            </div>

            <div className="space-y-6">
              {contactInfo.map((info, index) => (
                <motion.a
                  key={index}
                  href={info.href}
                  target={info.isExternal ? "_blank" : undefined}
                  rel={info.isExternal ? "noopener noreferrer" : undefined}
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.6, delay: index * 0.1 }}
                  viewport={{ once: true }}
                  whileHover={{ scale: 1.02 }}
                  className="flex items-center space-x-4 p-4 bg-gray-900 border border-gray-800 hover:border-gold/30 transition-colors duration-200 focus:outline-none focus:ring-2 focus:ring-gold/50 focus:ring-offset-2 focus:ring-offset-black cursor-pointer relative z-30"
                  aria-label={`${info.label}: ${info.value}`}
                  style={{ pointerEvents: 'auto' }}
                >
                  <div className="text-gold" aria-hidden="true">
                    {info.icon}
                  </div>
                  <div>
                    <div className="font-inter text-sm text-gray-400">
                      {info.label}
                    </div>
                    <div className="font-inter text-white font-medium">
                      {info.value}
                    </div>
                  </div>
                </motion.a>
              ))}
            </div>

            {/* Studio Hours */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.4 }}
              viewport={{ once: true }}
              className="p-6 bg-gray-900 border border-gray-800"
            >
              <h4 className="font-inter text-lg font-semibold text-white mb-4">
                Studio Hours
              </h4>
              <div className="space-y-2 font-inter text-gray-400">
                <div className="flex justify-between">
                  <span>Tuesday - Friday</span>
                  <span>12:00 PM - 8:00 PM</span>
                </div>
                <div className="flex justify-between">
                  <span>Saturday</span>
                  <span>10:00 AM - 6:00 PM</span>
                </div>
                <div className="flex justify-between">
                  <span>Sunday - Monday</span>
                  <span>By Appointment</span>
                </div>
              </div>
            </motion.div>
          </motion.div>
        </div>
      </div>
    </section>
  );
};

export default Contact;