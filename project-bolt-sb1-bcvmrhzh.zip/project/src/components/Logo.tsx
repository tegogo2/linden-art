import React from 'react';

interface LogoProps {
  size?: number;
  className?: string;
}

const Logo: React.FC<LogoProps> = ({ size = 32, className = "" }) => {
  return (
    <img
      src="/image.png"
      alt="Linden Art Logo"
      width={size}
      height={size}
      className={`object-contain ${className}`}
    />
  );
};

export default Logo;