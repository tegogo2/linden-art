import React from 'react';
import { motion } from 'framer-motion';
import { Award, Heart, Palette, Sparkles, Star } from 'lucide-react';

const About = () => {
  const values = [
    {
      icon: <Palette size={32} />,
      title: "Artistic Vision",
      description: "Every tattoo is a unique work of art, crafted with attention to detail and creative excellence.",
      gradient: "from-gold to-gold-light"
    },
    {
      icon: <Heart size={32} />,
      title: "Personal Connection",
      description: "I believe in creating meaningful pieces that resonate with your personal story and vision.",
      gradient: "from-gold-light to-gold"
    },
    {
      icon: <Award size={32} />,
      title: "Quality Craftsmanship",
      description: "Using only the finest equipment and techniques to ensure lasting, beautiful results.",
      gradient: "from-gold-dark to-gold-light"
    }
  ];

  return (
    <section id="about" className="py-20 bg-black relative overflow-hidden">
      {/* Enhanced background elements with gold theme */}
      <div className="absolute inset-0 opacity-10">
        <motion.div 
          animate={{ rotate: -360, scale: [1, 1.2, 1] }}
          transition={{ duration: 25, repeat: Infinity, ease: "linear" }}
          className="absolute top-32 right-24 w-28 h-28 border-2 border-gold rounded-full"
        />
        <motion.div 
          animate={{ scale: [1, 1.4, 1], opacity: [0.1, 0.4, 0.1] }}
          transition={{ duration: 5, repeat: Infinity, ease: "easeInOut" }}
          className="absolute bottom-24 left-16 w-36 h-36 bg-gradient-to-r from-gold/20 to-gold-light/20 rounded-full blur-2xl"
        />
        <motion.div
          animate={{ y: [0, -20, 0], x: [0, 15, 0] }}
          transition={{ duration: 4, repeat: Infinity, ease: "easeInOut" }}
          className="absolute top-1/4 left-1/3 text-gold/60"
        >
          <Star size={18} />
        </motion.div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">
          {/* Image Placeholder */}
          <motion.div
            initial={{ opacity: 0, x: -50 }}
            whileInView={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.8 }}
            viewport={{ once: true }}
            className="relative"
          >
            <div className="relative overflow-hidden rounded-lg bg-gray-900 border-2 border-dashed border-gray-700 flex items-center justify-center h-[600px]">
              <div className="text-center">
                <div className="text-gray-600 mb-4">
                  <svg width="64" height="64" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" className="mx-auto">
                    <rect x="3" y="3" width="18" height="18" rx="2" ry="2" stroke="currentColor" strokeWidth="2"/>
                    <circle cx="8.5" cy="8.5" r="1.5" stroke="currentColor" strokeWidth="2"/>
                    <polyline points="21,15 16,10 5,21" stroke="currentColor" strokeWidth="2"/>
                  </svg>
                </div>
                <p className="text-gray-500 font-inter text-lg">Artist Photo Placeholder</p>
                <p className="text-gray-600 font-inter text-sm mt-2">600 x 600 recommended</p>
              </div>
            </div>
            <div className="absolute -bottom-6 -right-6 w-24 h-24 border-4 border-gold bg-black"></div>
          </motion.div>

          {/* Content */}
          <motion.div
            initial={{ opacity: 0, x: 50 }}
            whileInView={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.8 }}
            viewport={{ once: true }}
            className="space-y-8"
          >
            <div className="relative">
              {/* Enhanced "Meet the Artist" heading with gold theme */}
              <motion.h2 
                initial={{ scale: 0.8, opacity: 0 }}
                whileInView={{ scale: 1, opacity: 1 }}
                transition={{ duration: 0.8, delay: 0.2 }}
                viewport={{ once: true }}
                className="font-playfair text-4xl md:text-5xl font-bold mb-6 relative"
              >
                <span className="bg-gradient-to-r from-gold via-gold-light to-gold bg-clip-text text-transparent drop-shadow-2xl">
                  Meet the Artist
                </span>
                <motion.div
                  animate={{ scale: [1, 1.15, 1], opacity: [0.4, 0.8, 0.4] }}
                  transition={{ duration: 3.5, repeat: Infinity, ease: "easeInOut" }}
                  className="absolute -inset-6 bg-gradient-to-r from-gold/20 via-gold-light/30 to-gold/20 rounded-2xl blur-2xl -z-10"
                />
              </motion.h2>

              {/* Decorative elements around heading */}
              <motion.div
                animate={{ rotate: 360, scale: [1, 1.3, 1] }}
                transition={{ duration: 6, repeat: Infinity, ease: "easeInOut" }}
                className="absolute -top-8 -left-8 text-gold"
              >
                <Sparkles size={22} />
              </motion.div>
              <motion.div
                animate={{ rotate: -360, scale: [1, 1.4, 1] }}
                transition={{ duration: 7, repeat: Infinity, ease: "easeInOut", delay: 1.5 }}
                className="absolute -top-4 -right-6 text-gold-light"
              >
                <Sparkles size={18} />
              </motion.div>

              <p className="font-inter text-lg text-gray-300 leading-relaxed mb-6">
                With over a decade of experience in the tattoo industry, I've dedicated my career to 
                transforming ideas into permanent works of art. My journey began with a passion for 
                drawing and evolved into a deep appreciation for the stories that skin can tell.
              </p>
              <p className="font-inter text-lg text-gray-300 leading-relaxed mb-8">
                I specialize in black and grey realism, intricate line work, and custom designs that 
                reflect each client's unique personality. Every session is an opportunity to create 
                something extraordinary together.
              </p>
            </div>

            {/* Enhanced Values with gold theme */}
            <div className="space-y-6">
              {values.map((value, index) => (
                <motion.div
                  key={index}
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.6, delay: index * 0.2 }}
                  viewport={{ once: true }}
                  whileHover={{ scale: 1.02, x: 10 }}
                  className="flex items-start space-x-4 p-4 rounded-lg hover:bg-gray-900/50 transition-all duration-300 group"
                >
                  <motion.div 
                    whileHover={{ scale: 1.2, rotate: 15 }}
                    className={`bg-gradient-to-r ${value.gradient} bg-clip-text text-transparent flex-shrink-0 mt-1 group-hover:drop-shadow-lg transition-all duration-300`}
                  >
                    {value.icon}
                  </motion.div>
                  <div>
                    <motion.h3 
                      className={`font-inter text-xl font-semibold mb-2 bg-gradient-to-r ${value.gradient} bg-clip-text text-transparent group-hover:scale-105 transition-transform duration-300 origin-left`}
                    >
                      {value.title}
                    </motion.h3>
                    <p className="font-inter text-gray-400 leading-relaxed group-hover:text-gray-300 transition-colors duration-300">
                      {value.description}
                    </p>
                  </div>
                </motion.div>
              ))}
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  );
};

export default About;