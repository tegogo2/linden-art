import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { Menu, X } from 'lucide-react';
import Logo from './Logo';

const Navigation = () => {
  const [isScrolled, setIsScrolled] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [activeSection, setActiveSection] = useState('home');

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 50);

      // Determine active section based on scroll position
      const sections = ['home', 'portfolio', 'about', 'testimonials', 'contact'];
      const scrollPosition = window.scrollY + 100;

      for (const section of sections) {
        const element = document.getElementById(section);
        if (element) {
          const { offsetTop, offsetHeight } = element;
          if (scrollPosition >= offsetTop && scrollPosition < offsetTop + offsetHeight) {
            setActiveSection(section);
            break;
          }
        }
      }
    };

    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const scrollToSection = (id: string) => {
    const element = document.getElementById(id);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
      setIsMobileMenuOpen(false);
    }
  };

  const navItems = [
    { name: 'Home', id: 'home' },
    { name: 'Portfolio', id: 'portfolio' },
    { name: 'About', id: 'about' },
    { name: 'Testimonials', id: 'testimonials' },
    { name: 'Book Now', id: 'contact' },
  ];

  return (
    <motion.nav
      initial={{ y: -100 }}
      animate={{ y: 0 }}
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-500 ${
        isScrolled 
          ? 'bg-black/95 backdrop-blur-md border-b border-gold/20 shadow-lg shadow-gold/10' 
          : 'bg-transparent'
      }`}
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-20">
          <motion.div
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
            className="flex items-center space-x-3 cursor-pointer group relative"
            onClick={() => scrollToSection('home')}
          >
            <motion.div
              whileHover={{ rotate: 5 }}
              className="relative"
            >
              <Logo size={32} className="text-gold transition-all duration-300 group-hover:drop-shadow-lg group-hover:drop-shadow-gold/50" />
              <motion.div
                initial={{ scale: 0, opacity: 0 }}
                animate={{ scale: 1, opacity: 1 }}
                transition={{ delay: 0.5, duration: 0.3 }}
                className="absolute -inset-1 bg-gold/20 rounded-full blur-sm opacity-0 group-hover:opacity-100 transition-opacity duration-300"
              />
            </motion.div>
            <div className="relative">
              <motion.span
                className="font-playfair text-xl md:text-2xl font-bold text-white group-hover:text-gold transition-colors duration-300"
                whileHover={{ letterSpacing: "0.05em" }}
              >
                Linden
              </motion.span>
              <motion.span
                className="font-playfair text-xl md:text-2xl font-bold bg-gradient-to-r from-gold via-gold-light to-gold bg-clip-text text-transparent ml-2"
                whileHover={{ letterSpacing: "0.05em" }}
              >
                Art
              </motion.span>
              <motion.div
                initial={{ scaleX: 0 }}
                animate={{ scaleX: 1 }}
                transition={{ delay: 0.8, duration: 0.6 }}
                className="absolute -bottom-1 left-0 right-0 h-0.5 bg-gradient-to-r from-transparent via-gold/50 to-transparent origin-center"
              />
            </div>
          </motion.div>

          {/* Desktop Navigation */}
          <div className="hidden md:flex space-x-8">
            {navItems.map((item, index) => (
              <motion.button
                key={item.id}
                initial={{ opacity: 0, y: -20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.1 * index, duration: 0.3 }}
                whileHover={{ 
                  scale: 1.05,
                  y: -2,
                }}
                whileTap={{ scale: 0.95 }}
                onClick={() => scrollToSection(item.id)}
                className={`relative transition-all duration-300 font-inter text-sm font-medium tracking-wide group ${
                  activeSection === item.id 
                    ? 'text-gold' 
                    : 'text-white hover:text-gold'
                }`}
              >
                {item.name}
                
                {/* Active indicator with glow */}
                <motion.div
                  className={`absolute -bottom-2 left-0 right-0 h-0.5 bg-gold origin-center transition-all duration-300 ${
                    activeSection === item.id 
                      ? 'scale-x-100 shadow-lg shadow-gold/50' 
                      : 'scale-x-0 group-hover:scale-x-100'
                  }`}
                />
                
                {/* Glow effect for active item */}
                <motion.div
                  className={`absolute inset-0 bg-gold/10 rounded-md transition-opacity duration-300 -z-10 ${
                    activeSection === item.id 
                      ? 'opacity-100' 
                      : 'opacity-0 group-hover:opacity-100'
                  }`}
                />
                
                {/* Additional glow for active state */}
                {activeSection === item.id && (
                  <motion.div
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    className="absolute -inset-2 bg-gold/5 rounded-lg blur-sm -z-20"
                  />
                )}
              </motion.button>
            ))}
          </div>

          {/* Mobile Menu Button */}
          <div className="md:hidden">
            <motion.button
              whileHover={{ scale: 1.1 }}
              whileTap={{ scale: 0.9 }}
              onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
              className="text-white hover:text-gold transition-colors duration-300 p-2 relative"
            >
              <motion.div
                animate={{ rotate: isMobileMenuOpen ? 180 : 0 }}
                transition={{ duration: 0.3 }}
              >
                {isMobileMenuOpen ? <X size={28} /> : <Menu size={28} />}
              </motion.div>
              <motion.div
                className="absolute inset-0 bg-gold/20 rounded-full opacity-0 hover:opacity-100 transition-opacity duration-300 -z-10"
              />
            </motion.button>
          </div>
        </div>
      </div>

      {/* Mobile Menu */}
      <motion.div
        initial={{ opacity: 0, height: 0 }}
        animate={{
          opacity: isMobileMenuOpen ? 1 : 0,
          height: isMobileMenuOpen ? 'auto' : 0,
        }}
        transition={{ duration: 0.3, ease: "easeInOut" }}
        className="md:hidden bg-black/98 backdrop-blur-md border-b border-gold/20 overflow-hidden"
      >
        <div className="px-4 py-6 space-y-4">
          {navItems.map((item, index) => (
            <motion.button
              key={item.id}
              initial={{ opacity: 0, x: -20 }}
              animate={{ 
                opacity: isMobileMenuOpen ? 1 : 0, 
                x: isMobileMenuOpen ? 0 : -20 
              }}
              transition={{ delay: isMobileMenuOpen ? 0.1 * index : 0, duration: 0.3 }}
              onClick={() => scrollToSection(item.id)}
              className={`block w-full text-left transition-colors duration-300 font-inter text-lg font-medium py-3 px-4 rounded-lg relative group ${
                activeSection === item.id 
                  ? 'text-gold bg-gold/10' 
                  : 'text-white hover:text-gold hover:bg-gold/10'
              }`}
            >
              {item.name}
              <motion.div
                className={`absolute left-0 top-0 bottom-0 w-1 bg-gold origin-top transition-transform duration-300 ${
                  activeSection === item.id 
                    ? 'scale-y-100 shadow-lg shadow-gold/50' 
                    : 'scale-y-0 group-hover:scale-y-100'
                }`}
              />
            </motion.button>
          ))}
        </div>
      </motion.div>
    </motion.nav>
  );
};

export default Navigation;