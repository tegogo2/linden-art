import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { X, ChevronLeft, ChevronRight, Sparkles, Zap } from 'lucide-react';

const Portfolio = () => {
  const [selectedImage, setSelectedImage] = useState<number | null>(null);

  // Updated portfolio images with new additions and removals
  const portfolioImages = [
    {
      src: "/0e0f5a305e0cdf83a5cc748fb12c3716.jpg",
      alt: "Intricate spine tattoo with mystical symbols and flowing lines"
    },
    {
      src: "/24b6c8ec76fde470dcdb8c40ada29508.jpg",
      alt: "Realistic wolf eyes tattoo on forearm"
    },
    {
      src: "/50 Hawaiian Tribal Tattoos - Designs, Ideas & Meaning - Tattoo Me Now.jpeg",
      alt: "Traditional Polynesian tribal tattoo design"
    },
    {
      src: "/_.jpeg",
      alt: "Flowing organic tattoo design with sun motifs"
    },
    {
      src: "/50b0f312c0fa63f8d60b85454c9430c3.jpg",
      alt: "Delicate botanical rib tattoo with fine line work"
    },
    {
      src: "/bc51e35125c1b0e43050f98b9d461108.jpg",
      alt: "Minimalist hummingbird tattoo on forearm"
    },
    {
      src: "/cc89bae7f5b6b2ed1d04bee40f9e78e1.jpg",
      alt: "Conceptual tattoo design with anatomical heart and brain elements"
    },
    {
      src: "/Spine tattoos for women.jpeg",
      alt: "Elegant floral spine tattoo design"
    },
    {
      src: "/Tattoo.jpeg",
      alt: "Simple memorial date tattoo"
    }
  ];

  const nextImage = () => {
    if (selectedImage !== null) {
      setSelectedImage((selectedImage + 1) % portfolioImages.length);
    }
  };

  const prevImage = () => {
    if (selectedImage !== null) {
      setSelectedImage(selectedImage === 0 ? portfolioImages.length - 1 : selectedImage - 1);
    }
  };

  return (
    <section id="portfolio" className="py-20 bg-gray-900 relative overflow-hidden">
      {/* Enhanced background elements with gold theme */}
      <div className="absolute inset-0 opacity-10">
        <motion.div 
          animate={{ rotate: 360, scale: [1, 1.1, 1] }}
          transition={{ duration: 20, repeat: Infinity, ease: "linear" }}
          className="absolute top-20 left-20 w-24 h-24 border-2 border-gold rounded-full"
        />
        <motion.div 
          animate={{ scale: [1, 1.3, 1], opacity: [0.1, 0.3, 0.1] }}
          transition={{ duration: 4, repeat: Infinity, ease: "easeInOut" }}
          className="absolute bottom-32 right-32 w-32 h-32 bg-gradient-to-r from-gold/20 to-gold-light/20 rounded-full blur-2xl"
        />
        <motion.div
          animate={{ y: [0, -15, 0], rotate: [0, 180, 360] }}
          transition={{ duration: 6, repeat: Infinity, ease: "easeInOut" }}
          className="absolute top-1/3 right-1/4 text-gold/60"
        >
          <Zap size={20} />
        </motion.div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          viewport={{ once: true }}
          className="text-center mb-16 relative"
        >
          {/* Enhanced Portfolio heading with gold gradient and effects */}
          <motion.h2 
            initial={{ scale: 0.8, opacity: 0 }}
            whileInView={{ scale: 1, opacity: 1 }}
            transition={{ duration: 0.8, delay: 0.2 }}
            viewport={{ once: true }}
            className="font-playfair text-4xl md:text-5xl font-bold mb-4 relative"
          >
            <span className="bg-gradient-to-r from-gold via-gold-light to-gold bg-clip-text text-transparent drop-shadow-2xl">
              Portfolio
            </span>
            <motion.div
              animate={{ scale: [1, 1.2, 1], opacity: [0.3, 0.8, 0.3] }}
              transition={{ duration: 3, repeat: Infinity, ease: "easeInOut" }}
              className="absolute -inset-6 bg-gradient-to-r from-gold/20 via-gold-light/30 to-gold/20 rounded-2xl blur-2xl -z-10"
            />
          </motion.h2>

          {/* Decorative sparkles around Portfolio heading */}
          <motion.div
            animate={{ rotate: 360, scale: [1, 1.3, 1] }}
            transition={{ duration: 4, repeat: Infinity, ease: "easeInOut" }}
            className="absolute -top-6 -left-12 text-gold"
          >
            <Sparkles size={24} />
          </motion.div>
          <motion.div
            animate={{ rotate: -360, scale: [1, 1.4, 1] }}
            transition={{ duration: 5, repeat: Infinity, ease: "easeInOut", delay: 1 }}
            className="absolute -top-4 -right-10 text-gold-light"
          >
            <Sparkles size={20} />
          </motion.div>
          <motion.div
            animate={{ y: [0, -10, 0], scale: [1, 1.2, 1] }}
            transition={{ duration: 3, repeat: Infinity, ease: "easeInOut", delay: 2 }}
            className="absolute -bottom-2 left-1/4 text-gold"
          >
            <Sparkles size={16} />
          </motion.div>

          <motion.p 
            initial={{ opacity: 0 }}
            whileInView={{ opacity: 1 }}
            transition={{ duration: 0.6, delay: 0.4 }}
            viewport={{ once: true }}
            className="font-inter text-lg text-gray-300 max-w-2xl mx-auto"
          >
            A curated collection of custom pieces, each telling a 
            <span className="bg-gradient-to-r from-gold to-gold-light bg-clip-text text-transparent font-semibold"> unique story </span>
            through ink and artistry.
          </motion.p>
        </motion.div>

        {/* Masonry Grid */}
        <div className="columns-1 md:columns-2 lg:columns-3 gap-6 space-y-6">
          {portfolioImages.map((image, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: index * 0.1 }}
              viewport={{ once: true }}
              whileHover={{ scale: 1.02 }}
              className="break-inside-avoid cursor-pointer group relative overflow-hidden"
              onClick={() => setSelectedImage(index)}
            >
              <img
                src={image.src}
                alt={image.alt}
                className="w-full rounded-lg transition-transform duration-300 group-hover:scale-105"
                loading="lazy"
              />
              <div className="absolute inset-0 bg-black/0 group-hover:bg-black/20 transition-colors duration-300 rounded-lg flex items-center justify-center">
                <div className="opacity-0 group-hover:opacity-100 transition-opacity duration-300 text-white text-sm font-inter bg-black/50 px-3 py-1 rounded">
                  View Larger
                </div>
              </div>
            </motion.div>
          ))}
        </div>

        {/* Enhanced Specializing In Section */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.3 }}
          viewport={{ once: true }}
          className="mt-20 text-center relative"
        >
          <motion.h3 
            initial={{ scale: 0.9, opacity: 0 }}
            whileInView={{ scale: 1, opacity: 1 }}
            transition={{ duration: 0.6, delay: 0.2 }}
            viewport={{ once: true }}
            className="font-playfair text-2xl md:text-3xl font-bold mb-8 relative"
          >
            <span className="bg-gradient-to-r from-gold-light via-gold to-gold-dark bg-clip-text text-transparent drop-shadow-lg">
              Specializing In
            </span>
            <motion.div
              animate={{ scale: [1, 1.1, 1], opacity: [0.4, 0.7, 0.4] }}
              transition={{ duration: 2.5, repeat: Infinity, ease: "easeInOut" }}
              className="absolute -inset-4 bg-gradient-to-r from-gold/15 via-gold-light/20 to-gold/15 rounded-xl blur-xl -z-10"
            />
          </motion.h3>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <motion.div 
              whileHover={{ scale: 1.05, y: -5 }}
              className="text-center group"
            >
              <motion.div 
                animate={{ rotate: [0, 10, -10, 0] }}
                transition={{ duration: 4, repeat: Infinity, ease: "easeInOut" }}
                className="text-4xl mb-4 group-hover:scale-110 transition-transform duration-300"
              >
                <span className="bg-gradient-to-r from-gold to-gold-light bg-clip-text text-transparent">✨</span>
              </motion.div>
              <h4 className="font-inter text-lg font-semibold bg-gradient-to-r from-gold to-gold-light bg-clip-text text-transparent mb-2">Fine Line</h4>
              <p className="font-inter text-gray-400 text-sm group-hover:text-gray-300 transition-colors duration-300">Delicate, precise linework for minimalist and detailed designs</p>
            </motion.div>
            
            <motion.div 
              whileHover={{ scale: 1.05, y: -5 }}
              className="text-center group"
            >
              <motion.div 
                animate={{ scale: [1, 1.2, 1] }}
                transition={{ duration: 3, repeat: Infinity, ease: "easeInOut", delay: 1 }}
                className="text-4xl mb-4 group-hover:scale-110 transition-transform duration-300"
              >
                <span className="bg-gradient-to-r from-gold-light to-gold bg-clip-text text-transparent">⚡</span>
              </motion.div>
              <h4 className="font-inter text-lg font-semibold bg-gradient-to-r from-gold-light to-gold bg-clip-text text-transparent mb-2">Pico Laser</h4>
              <p className="font-inter text-gray-400 text-sm group-hover:text-gray-300 transition-colors duration-300">Advanced laser technology for safe tattoo removal and modification</p>
            </motion.div>
            
            <motion.div 
              whileHover={{ scale: 1.05, y: -5 }}
              className="text-center group"
            >
              <motion.div 
                animate={{ rotate: [0, -15, 15, 0] }}
                transition={{ duration: 5, repeat: Infinity, ease: "easeInOut", delay: 2 }}
                className="text-4xl mb-4 group-hover:scale-110 transition-transform duration-300"
              >
                <span className="bg-gradient-to-r from-gold-dark to-gold bg-clip-text text-transparent">💎</span>
              </motion.div>
              <h4 className="font-inter text-lg font-semibold bg-gradient-to-r from-gold-dark to-gold bg-clip-text text-transparent mb-2">Titanium Jewelry</h4>
              <p className="font-inter text-gray-400 text-sm group-hover:text-gray-300 transition-colors duration-300">Premium body jewelry for fresh piercings and upgrades</p>
            </motion.div>
          </div>
        </motion.div>
      </div>

      {/* Lightbox */}
      <AnimatePresence>
        {selectedImage !== null && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-black/95 z-50 flex items-center justify-center p-4"
            onClick={() => setSelectedImage(null)}
          >
            <div className="relative max-w-4xl max-h-full">
              <motion.img
                initial={{ scale: 0.8 }}
                animate={{ scale: 1 }}
                exit={{ scale: 0.8 }}
                src={portfolioImages[selectedImage].src}
                alt={portfolioImages[selectedImage].alt}
                className="max-w-full max-h-full object-contain rounded-lg"
                onClick={(e) => e.stopPropagation()}
              />
              
              {/* Close Button */}
              <button
                onClick={() => setSelectedImage(null)}
                className="absolute top-4 right-4 text-white hover:text-gold transition-colors duration-200 bg-black/50 rounded-full p-2"
              >
                <X size={24} />
              </button>

              {/* Navigation Buttons */}
              <button
                onClick={(e) => { e.stopPropagation(); prevImage(); }}
                className="absolute left-4 top-1/2 transform -translate-y-1/2 text-white hover:text-gold transition-colors duration-200 bg-black/50 rounded-full p-2"
              >
                <ChevronLeft size={32} />
              </button>
              
              <button
                onClick={(e) => { e.stopPropagation(); nextImage(); }}
                className="absolute right-4 top-1/2 transform -translate-y-1/2 text-white hover:text-gold transition-colors duration-200 bg-black/50 rounded-full p-2"
              >
                <ChevronRight size={32} />
              </button>

              {/* Image Counter */}
              <div className="absolute bottom-4 left-1/2 transform -translate-x-1/2 text-white bg-black/50 px-3 py-1 rounded text-sm">
                {selectedImage + 1} / {portfolioImages.length}
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </section>
  );
};

export default Portfolio;